
  # Industrial Data System Control and Data Projection Demo

  This is a code bundle for Industrial Data System Control and Data Projection Demo. The original project is available at https://www.figma.com/design/p0dqbh9LVPtdJkgn8A4R3K/Industrial-Data-System-Control-and-Data-Projection-Demo.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  